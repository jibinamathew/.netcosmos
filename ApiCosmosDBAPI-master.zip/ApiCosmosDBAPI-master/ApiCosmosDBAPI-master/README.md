# ApiCosmosDBAPI
## Microsoft Link
https://docs.microsoft.com/en-us/azure/cosmos-db/sql-api-dotnet-application#create-a-new-mvc-application

## YouTube Video
https://www.youtube.com/watch?v=s2CA-0R9T9g
